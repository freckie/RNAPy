from RNAPy.RNAPy import RNA
from RNAPy.RNAPy_AA import RNAPy_AA

